<?php

use App\Http\Controllers\ProfileController;
use Illuminate\Support\Facades\Route;
use App\Events\MessageSent;

Route::get('/', function () {
    return view('welcome');
});

Route::get('/dashboard', function () {
    return view('dashboard');
})->middleware(['auth', 'verified'])->name('dashboard');

Route::middleware('auth')->group(function () {
    Route::get('/profile', [ProfileController::class, 'edit'])->name('profile.edit');
    Route::patch('/profile', [ProfileController::class, 'update'])->name('profile.update');
    Route::delete('/profile', [ProfileController::class, 'destroy'])->name('profile.destroy');
});
Route::post('/chat/send', function () {
    request()->validate([
        'message' => 'required|string|max:1000',
    ]);

    broadcast(new MessageSent(request('message')));

    return response()->json([
        'success' => true,
    ]);
})->middleware('auth');

Route::get('/chat', function () {
    return view('chat');
})->middleware('auth')->name('chat');

require __DIR__.'/auth.php';
