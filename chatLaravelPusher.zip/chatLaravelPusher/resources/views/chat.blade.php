<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <title>Chat</title>

    @vite(['resources/css/app.css', 'resources/js/app.js'])
</head>
<body>

    <div>
        <h1>Chat</h1>

        <div id="messages"></div>

        <form id="chat-form">
            <input
                type="text"
                id="message"
                placeholder="Digite sua mensagem..."
                required
            >

            <button type="submit">Enviar</button>
        </form>
    </div>

    <script>
        const form = document.getElementById('chat-form');
        const input = document.getElementById('message');
        const messages = document.getElementById('messages');

        window.Echo.channel('chat')
            .listen('MessageSent', (event) => {
                const message = document.createElement('p');

                message.textContent = event.message;

                messages.appendChild(message);
            });

        form.addEventListener('submit', async (e) => {
            e.preventDefault();

            const message = input.value;

            await fetch('/chat/send', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRF-TOKEN': document
                        .querySelector('meta[name="csrf-token"]')
                        .getAttribute('content'),
                    'Accept': 'application/json'
                },
                body: JSON.stringify({
                    message: message
                })
            });

            input.value = '';
        });
    </script>

</body>
</html>